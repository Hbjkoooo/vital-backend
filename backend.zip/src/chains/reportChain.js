const { ChatPromptTemplate } = require('@langchain/core/prompts');
const { StringOutputParser } = require('@langchain/core/output_parsers');
const { extractLLM, analysisLLM } = require('../utils/llm');
const { parseIndicators, indicatorsToText } = require('../parsers/indicatorParser');

// ============================================================
// 模板定义
// ============================================================
const TEMPLATES = {
  comprehensive: {
    label: '综合健康评估',
    systemExtra: `你的任务是帮用户读懂这份体检报告，用通俗易懂的语言解释每一个异常指标。

要求：
- 对每个异常指标，说清楚：这个指标是什么、正常范围是多少、我的数值意味着什么、可能的原因是什么
- 对正常指标做简要汇总即可，不需要逐条解释
- 语言通俗，把专业术语翻译成普通人能懂的话，但可以稍微书面一些
- 风险提示要客观，不要过度渲染，也不要轻描淡写
- 不要给出生活建议，那是个性化版的事，这里只做报告解读`,
    outputFormat: `## 整体概况
（用1-2句话总结这份报告的整体情况，给出健康评分的依据）

## 异常指标详解
（对每个异常指标单独说明：指标含义、我的数值、正常范围、意味着什么、可能原因）

## 正常指标汇总
（简要列出正常的指标，说明整体情况良好的方面）

## 需要关注的事项
（基于本次报告，提示需要复查或持续关注的内容）`,
  },

  personalized: {
    label: '个性化健康评估',
    systemExtra: `你是用户的私人健康顾问，你已经了解这个人的基本情况（见用户信息），现在要结合他/她的体检结果给出专属建议。

要求：
- 建议必须贴合用户的实际生活，不能泛泛而谈
- 如果用户有家族病史，即使相关指标在正常范围内也要重点提示
- 运动、饮食建议要具体到这个人能做到的事，比如"适合你的运动是XX，每周XX次"
- 要考虑用户的年龄、职业、作息、健康目标，给出真正有用的建议
- 语气像朋友，不要太生硬`,
    outputFormat: `## 你的健康画像
（结合用户信息和体检数据，用2-3句话描述这个人当前的健康状态）

## 重点关注指标
（结合用户个人情况，解释哪些指标对他/她来说需要特别注意，以及为什么）

## 你的专属健康风险
（基于用户画像+体检数据，分析这个人特有的健康风险，比如久坐+某指标偏高意味着什么）

## 个性化行动建议
### 饮食调整
（具体到这个人能做到的饮食改变）
### 运动方案
（结合用户运动频率和身体状况，给出具体可执行的运动建议）
### 作息与生活习惯
（针对用户实际作息给出建议）

## 近期目标
（结合用户的健康目标，给出1-3个近期可执行的小目标）`,
  },
};

// ============================================================
// 健康评分计算
// ============================================================
const INDICATOR_WEIGHTS = {
  bloodGlucose:     15,
  hba1c:            15,
  systolicBP:       12,
  diastolicBP:      12,
  totalCholesterol: 10,
  triglycerides:    10,
  ldl:               8,
  hdl:               6,
  alt:               8,
  ast:               8,
  ggt:               5,
  uricAcid:          6,
  creatinine:        6,
  hemoglobin:        5,
  bmi:               5,
};
const DEFAULT_WEIGHT = 3;

const calcHealthScore = (indicators) => {
  let totalDeduction = 0;

  for (const ind of indicators) {
    const isAbnormal = ind.is_abnormal ?? ind.isAbnormal;
    if (!isAbnormal) continue;

    const weight = INDICATOR_WEIGHTS[ind.indicator_key ?? ind.key] ?? DEFAULT_WEIGHT;
    const value  = parseFloat(ind.value);
    const min    = parseFloat(ind.normal_min ?? ind.normalMin);
    const max    = parseFloat(ind.normal_max ?? ind.normalMax);

    let deviationRatio = 0;
    if (!isNaN(min) && !isNaN(max) && (max - min) > 0) {
      if (value < min) deviationRatio = (min - value) / (max - min);
      if (value > max) deviationRatio = (value - max) / (max - min);
    }

    let ratio = 0;
    if (deviationRatio <= 0.1)      ratio = 0.3;
    else if (deviationRatio <= 0.3) ratio = 0.6;
    else                            ratio = 1.0;

    totalDeduction += weight * ratio;
  }

  return Math.min(95, Math.max(40, Math.round(100 - totalDeduction)));
};


// ============================================================
// 提取体检指标
// ============================================================
const extractIndicators = async (rawText) => {
  const prompt = ChatPromptTemplate.fromMessages([
    ['system', `从体检报告原始文本中提取所有健康检测指标。
严格返回JSON数组，不要任何额外文字或代码块：
[{{"key":"英文camelCase","label":"中文名","value":数字,"unit":"单位","referenceRange":"参考范围","normalMin":数字或null,"normalMax":数字或null,"isAbnormal":true或false}}]`],
    ['human', '体检报告原文：\n{rawText}'],
  ]);
  const chain = prompt.pipe(extractLLM).pipe(new StringOutputParser());
  const result = await chain.invoke({ rawText });
  return parseIndicators(result);
};

// ============================================================
// 生成健康报告
// ============================================================
const generateReport = async (indicators, userProfile, templateId = 'comprehensive') => {
  const template = TEMPLATES[templateId] || TEMPLATES.comprehensive;

  // ✅ 综合版只传基础信息，个性化版传全量
  const profileText = templateId === 'comprehensive'
    ? formatBasicProfile(userProfile)
    : formatUserProfile(userProfile);

  const prompt = ChatPromptTemplate.fromMessages([
    ['system', `你是 Vitalic 智能健康助手，根据用户体检指标生成健康分析报告。
用户基本信息：{userProfile}
报告类型：{templateLabel}

{systemExtra}

输出格式（Markdown）：
{outputFormat}

---
⚠️ 本报告由AI生成，仅供健康参考，不构成医疗诊断或治疗建议。`],
    ['human', '以下是该用户的全部体检指标：\n{indicatorsText}\n\n请生成{templateLabel}。'],
  ]);

  const chain = prompt.pipe(analysisLLM).pipe(new StringOutputParser());
  const markdown = await chain.invoke({
    userProfile:    profileText,
    templateLabel:  template.label,
    systemExtra:    template.systemExtra,
    outputFormat:   template.outputFormat,
    indicatorsText: indicatorsToText(indicators),
  });

  const summary = extractSummary(markdown);
// 改后
const healthScore = calcHealthScore(indicators);

  return { markdown, summary, healthScore, templateId };
};
// 综合版只用年龄性别
const formatBasicProfile = (profile = {}) => {
  const parts = [];
  if (profile.age)    parts.push(`年龄:${profile.age}岁`);
  if (profile.gender) parts.push(`性别:${profile.gender === 'male' ? '男' : '女'}`);
  if (profile.height && profile.weight) {
    parts.push(`BMI:${(profile.weight / Math.pow(profile.height / 100, 2)).toFixed(1)}`);
  }
  return parts.join('，') || '未填写';
};

// summary 提取更可靠
const extractSummary = (markdown) => {
  const lines = markdown.split('\n').filter(l => l.trim() && !l.startsWith('#'));
  return lines[0]?.slice(0, 100) + '...' || markdown.slice(0, 100) + '...';
};

// ============================================================
// 格式化用户画像（传入 Prompt）
// ============================================================
const formatUserProfile = (profile = {}) => {
  const parts = [];

  // 基础信息
  if (profile.name)   parts.push(`姓名:${profile.name}`);
  if (profile.age)    parts.push(`年龄:${profile.age}岁`);
  if (profile.gender) parts.push(`性别:${profile.gender === 'male' ? '男' : '女'}`);
  if (profile.height) parts.push(`身高:${profile.height}cm`);
  if (profile.weight) parts.push(`体重:${profile.weight}kg`);
  if (profile.height && profile.weight) {
    parts.push(`BMI:${(profile.weight / Math.pow(profile.height / 100, 2)).toFixed(1)}`);
  }

  // 生活习惯
  const sleepMap    = { early: '早睡早起', normal: '作息规律', late: '晚睡晚起', irregular: '作息不规律' };
  const exerciseMap = { none: '不运动', '1-2': '每周1-2次', '3+': '每周3次以上' };
  const smokingMap  = { none: '不吸烟', quit: '已戒烟', occasional: '偶尔吸烟', daily: '每天吸烟' };
  const drinkingMap = { none: '不饮酒', occasional: '偶尔饮酒', weekly: '每周饮酒', daily: '每天饮酒' };

  if (profile.sleep_pattern)  parts.push(`作息:${sleepMap[profile.sleep_pattern] || profile.sleep_pattern}`);
  if (profile.sleep_hours)    parts.push(`睡眠时长:${profile.sleep_hours}小时`);
  if (profile.exercise_freq)  parts.push(`运动频率:${exerciseMap[profile.exercise_freq] || profile.exercise_freq}`);
  if (profile.smoking_status) parts.push(`吸烟:${smokingMap[profile.smoking_status] || profile.smoking_status}`);
  if (profile.drinking_status)parts.push(`饮酒:${drinkingMap[profile.drinking_status] || profile.drinking_status}`);
  if (profile.occupation)     parts.push(`职业:${profile.occupation}`);

  // 既往史与家族史
  if (profile.med_history?.length)    parts.push(`既往病史:${profile.med_history.join('、')}`);
  if (profile.family_history?.length) parts.push(`家族病史:${profile.family_history.join('、')}`);
  if (profile.allergies)              parts.push(`过敏史:${profile.allergies}`);

  // 健康目标
  if (profile.health_goal) parts.push(`健康目标:${profile.health_goal}`);

  return parts.join('，') || '未填写';
};

module.exports = { extractIndicators, generateReport, formatUserProfile };