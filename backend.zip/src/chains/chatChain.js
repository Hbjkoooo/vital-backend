const { ChatPromptTemplate } = require('@langchain/core/prompts');
const { StringOutputParser } = require('@langchain/core/output_parsers');
const { getLLM } = require('../utils/llm');
const { indicatorsToText, parseGoals } = require('../parsers/indicatorParser');
const { formatUserProfile } = require('./reportChain');

const chatLLM = getLLM({ temperature: 0.7, maxTokens: 800 });

const buildHistory = (messages = []) =>
  messages.slice(-10).map(m => ({
    role: m.role === 'user' ? 'human' : 'assistant',
    content: m.content,
  }));

const chatWithReport = async (input, history, reportContext) => {
  const { indicators = [], reportSummary = '', userProfile = {} } = reportContext;
  const prompt = ChatPromptTemplate.fromMessages([
    ['system', `你是 Vitalic 的报告解读助手，风格像一个有耐心的全科医生。

    用户信息：{userProfile}
    体检指标：{indicatorsSummary}
    报告结论：{reportSummary}
    
    回复要求：
    - 先给结论，再解释，不铺垫不绕弯
    - 如果用户担心某个指标，先明确告知严不严重，再说原因
    - 该说没事就直接说没事，不要模棱两可
    - 150字以内，分短句，不写长段落
    - 不要开场白，不要"您好"，直接回答
    - 有数据支撑时引用具体数值，让用户有据可依
    ⚠️ 内容仅供健康参考，不构成医疗诊断建议。`],
        ...buildHistory(history).map(m => [m.role, m.content]),
        ['human', '{input}'],
      ]);
  const chain = prompt.pipe(chatLLM).pipe(new StringOutputParser());
  return chain.invoke({
    input,
    userProfile: formatUserProfile(userProfile),
    indicatorsSummary: indicatorsToText(indicators.slice(0, 8)),
    reportSummary: reportSummary || '暂无报告摘要',
  });
};

const chatWithAssistant = async (input, history, assistantContext) => {
  const { userProfile = {}, recentIndicators = [] } = assistantContext;
  const recentText = recentIndicators
    .slice(0, 10)
    .map(i => `${i.indicator_label || i.label}: ${i.value}${i.unit}`)
    .join('、') || '暂无数据';
  const prompt = ChatPromptTemplate.fromMessages([
    ['system', `你是用户的专属健康朋友，懂医学但说话像朋友不像医生。

    用户档案：{userProfile}
    近期指标：{recentIndicators}
    
    回复要求：
    - 语气随意亲切，可以用口语，像微信聊天
    - 100字以内，简短有温度
    - 结合用户的实际情况关心他，比如职业、作息、健康目标
    - 不需要每次都给建议，有时候共情比建议更重要
    - 不要开场白，直接说
    ⚠️ 内容仅供健康参考，不构成医疗诊断建议。`],
        ...buildHistory(history).map(m => [m.role, m.content]),
        ['human', '{input}'],
      ]);
  const chain = prompt.pipe(chatLLM).pipe(new StringOutputParser());
  return chain.invoke({ input, userProfile: formatUserProfile(userProfile), recentIndicators: recentText });
};

const chatForGoalSetup = async (input, history, goalContext) => {
  const { userProfile = {}, abnormalIndicators = [] } = goalContext;
  const abnormalText = abnormalIndicators
    .map(i => `${i.indicator_label || i.label}: ${i.value}${i.unit}偏高`)
    .join('、') || '暂无异常';
  const prompt = ChatPromptTemplate.fromMessages([
    ['system', `你是健康目标规划助手，帮助用户一步步制定健康目标和打卡任务。

用户档案：{userProfile}
异常指标：{abnormalIndicators}

对话流程（严格按顺序引导，不得跳过）：

第一阶段：确定目标
- 引导用户说出想改善的健康方向
- 结合用户画像给出1-2个目标建议
- 确认目标名称和坚持周期（如30天、60天）
- 用户明确确认后才进入第二阶段，说"好的，目标定好了！接下来我们来制定具体任务 💪"

第二阶段：制定任务
- 每次只建议一个任务
- 建议任务后必须问频率，只能给出以下三个选项，不能有其他选项：
  · 每天
  · 工作日（周一到周五）
  · 每周几（让用户从周一到周日中选一天）
- 严禁出现"每周几次"、"每周两次"等频次表达，只支持固定的某一天或每天
- 用户明确选择以上三个选项之一后才算确认，才能继续下一个任务
- 3个任务确认后问"还需要添加其他任务吗？"
- 用户满意后说"好的，我来为你生成目标方案！"

边界规则：
- 如果用户跑题或闲聊，温和地把话题拉回来继续当前阶段
- 必须完成至少1个任务的完整确认（含频率）才能生成
- 不要重复已确认的内容

语气亲切，每次回复100字以内，每次只问一个问题。
⚠️ 不构成医疗建议。`],
    ...buildHistory(history).map(m => [m.role, m.content]),
    ['human', '{input}'],
  ]);
  const chain = prompt.pipe(chatLLM).pipe(new StringOutputParser());
  return chain.invoke({ input, userProfile: formatUserProfile(userProfile), abnormalIndicators: abnormalText });
};

const finalizeGoals = async (history, goalContext) => {
  const { userProfile = {}, abnormalIndicators = [] } = goalContext;
  const conversationHistory = history
    .map(m => `${m.role === 'user' ? '用户' : '助手'}: ${m.content}`)
    .join('\n');
  const prompt = ChatPromptTemplate.fromMessages([
    ['system', `根据对话历史生成1-3个健康目标，严格返回JSON，不要其他内容：
    {{"goals":[{{"title":"目标名称","description":"描述","targetDays":30,"tasks":[{{"title":"任务名","frequency":"频率"}}]}}]}}
    
    frequency 只能是以下值之一：每天、工作日、周一、周二、周三、周四、周五、周六、周日
    严禁出现"每周X次"、"每两天"等其他格式。`],
    ['human', '对话历史：{conversationHistory}\n用户档案：{userProfile}\n异常指标：{abnormalIndicators}'],
  ]);
  const chain = prompt.pipe(getLLM({ temperature: 0.1 })).pipe(new StringOutputParser());
  const result = await chain.invoke({
    conversationHistory,
    userProfile: formatUserProfile(userProfile),
    abnormalIndicators: abnormalIndicators.map(i => `${i.label}偏高`).join('、') || '无',
  });
  return parseGoals(result);
};

module.exports = { chatWithReport, chatWithAssistant, chatForGoalSetup, finalizeGoals };
